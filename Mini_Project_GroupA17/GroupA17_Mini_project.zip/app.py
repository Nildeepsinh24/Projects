import os
import csv
from datetime import datetime
from flask import Flask, render_template, request, redirect, session, flash

app = Flask(__name__)
app.secret_key = 'secure123'

USERNAME = 'admin'
PASSWORD = 'admin123'

INVENTORY_FILE = "inventory.csv"
TRANSACTION_FILE = "transactions.csv"

@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        if request.form['username'] == USERNAME and request.form['password'] == PASSWORD:
            session['user'] = USERNAME
            return redirect('/dashboard')
        else:
            return render_template('login.html', error="Invalid ID or Password")
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.pop('user', None)
    return redirect('/')

def require_login(f):
    from functools import wraps
    @wraps(f)
    def wrapper(*args, **kwargs):
        if 'user' not in session:
            return redirect('/')
        return f(*args, **kwargs)
    return wrapper

@app.route('/dashboard')
@require_login
def dashboard():
    return render_template('dashboard.html')

@app.route('/import', methods=['GET', 'POST'])
@require_login
def import_product():
    if request.method == 'POST':
        try:
            products = load_inventory()
            product_id = generate_next_product_id(products)
            name = request.form['name']
            category = request.form['category']
            supplier = request.form['supplier']
            origin = request.form['origin']
            quantity = int(request.form['quantity'])
            import_price = float(request.form['import_price'])
            today = datetime.now().strftime('%Y-%m-%d')

            if product_id in products:
    
                # Update name
                existing_names = products[product_id]['Product Name'].split(',') if products[product_id]['Product Name'] else []
                if name.strip() not in [n.strip() for n in existing_names]:
                    existing_names.append(name.strip())
                products[product_id]['Product Name'] = ', '.join(existing_names)

                # Update import price
                existing_prices = products[product_id]['Import Price'].split(',') if products[product_id]['Import Price'] else []
                if str(import_price) not in [p.strip() for p in existing_prices]:
                    existing_prices.append(str(import_price))
                products[product_id]['Import Price'] = ', '.join(existing_prices)

                # Update import date
                existing_dates = products[product_id]['Import Date'].split(',') if products[product_id]['Import Date'] else []
                if today not in [d.strip() for d in existing_dates]:
                    existing_dates.append(today)
                products[product_id]['Import Date'] = ', '.join(existing_dates)

            else:
                # New product entry
                products[product_id] = {
                    'Product ID': product_id,
                    'Product Name': name.strip(),
                    'Category': category,
                    'Supplier': supplier,
                    'Country of Origin': origin,
                    'Quantity': quantity,
                    'Import Price': str(import_price),
                    'Export Price': '',
                    'Import Date': today,
                    'Export Date': '',
                    'Status': 'Available'
                }

            save_inventory(products)
            log_transaction("Imported", product_id, quantity, import_price)

            flash(f'✅ Product {product_id} imported successfully.', 'success')
        except Exception as e:
            print("Import Error:", e)
            flash(f'❌ Import failed: {str(e)}', 'error')

    return render_template('import.html')
    
@app.route('/export', methods=['GET', 'POST'])
@require_login
def export_product():
    if request.method == 'POST':
        try:
            products = load_inventory()
            product_id = request.form['product_id']
            quantity = int(request.form['quantity'])
            export_price = float(request.form['export_price'])
            today = datetime.now().strftime('%Y-%m-%d')

            if product_id in products:
                current_qty = int(products[product_id]['Quantity'])
                if current_qty >= quantity:
                    # Update inventory
                    products[product_id]['Quantity'] = current_qty - quantity

                    prev_prices = [p.strip() for p in products[product_id]['Export Price'].split(',')] if products[product_id]['Export Price'] else []
                    if str(export_price) not in prev_prices:
                        prev_prices.append(str(export_price))
                    products[product_id]['Export Price'] = ', '.join(prev_prices)

                    prev_dates = [d.strip() for d in products[product_id]['Export Date'].split(',')] if products[product_id]['Export Date'] else []
                    if today not in prev_dates:
                        prev_dates.append(today)
                    products[product_id]['Export Date'] = ', '.join(prev_dates)

                    products[product_id]['Status'] = 'Exported'
                    save_inventory(products)
                    log_transaction("Exported", product_id, quantity, export_price)

                    flash(f'✅ Product {product_id} exported successfully.', 'success')
                else:
                    flash(f'❌ Not enough quantity. Only {current_qty} units available.', 'error')
            else:
                flash(f'❌ Product ID {product_id} not found.', 'error')

        except Exception as e:
            print("Export Error:", e)
            flash(f'❌ Export failed: {str(e)}', 'error')

        return render_template('export.html')  # ✅ Stay on the same page

    return render_template('export.html')

@app.route("/delete", methods=["GET", "POST"])
@require_login
def delete_product():
    message = ""
    if request.method == "POST":
        product_id = request.form["product_id"].strip()
        products = load_inventory()

        if product_id in products:
            del products[product_id]
            save_inventory(products)
            log_transaction("Deleted", product_id, "-", "-")  # Log deletion
            message = f"✅ Product with ID {product_id} deleted successfully."
        else:
            message = f"❌ Product ID {product_id} not found."

    return render_template("delete.html", message=message)


@app.route('/update', methods=['GET', 'POST'])
@require_login
def update_product():
    products = load_inventory()
    product = None
    found = False
    message = None

    if request.method == 'POST':
        product_id = request.form['product_id']

        # If the user clicked 'fetch'
        if 'fetch' in request.form:
            if product_id in products:
                product = products[product_id]
                found = True
            else:
                message = "❌ Product not found."

        # If the user clicked 'update'
        elif 'update' in request.form:
            if product_id in products:
                if products[product_id]['Status'].lower() == 'exported':
                    message = "❌ Product has already been exported and cannot be updated."
                    product = products[product_id]
                    found = True
                else:
                    products[product_id]['Product Name'] = request.form['name']
                    products[product_id]['Category'] = request.form['category']
                    products[product_id]['Supplier'] = request.form['supplier']
                    products[product_id]['Country of Origin'] = request.form['origin']
                    products[product_id]['Quantity'] = request.form['quantity']
                    products[product_id]['Import Price'] = request.form['import_price']
                    
                    save_inventory(products)

                    log_transaction("Updated", product_id, request.form['quantity'], request.form['import_price'])

                    message = "✅ Product updated successfully."
                    product = products[product_id]
                    found = True
            else:
                message = "❌ Product not found."

    return render_template('update.html', product=product, found=found, message=message)

@app.route('/search', methods=['GET', 'POST'])
@require_login
def search_product():
    product = None
    not_found = False

    if request.method == 'POST':
        search_type = request.form.get('search_type')
        search_value = request.form.get('search_value', '').strip().lower()
        products = load_inventory()

        if search_type == 'id':
            # Exact case-insensitive match on Product ID
            for pid, p in products.items():
                if pid.strip().lower() == search_value:
                    product = p
                    break

        elif search_type == 'name':
            # Exact case-insensitive match on Product Name
            for p in products.values():
                if p['Product Name'].strip().lower() == search_value:
                    product = p
                    break

        if not product:
            not_found = True

    return render_template('search.html', product=product, not_found=not_found)


def load_inventory():
    inventory = {}
    if os.path.exists(INVENTORY_FILE):
        with open(INVENTORY_FILE, "r", newline='') as file:
            reader = csv.DictReader(file)
            for row in reader:
                inventory[row['Product ID']] = row
    return inventory

@app.route('/forgot-password', methods=['GET', 'POST'])
def forgot_password():
    if request.method == 'POST':
        email = request.form['email']
        # Here, send an email or show a message
        return "Password reset link sent to your email."
    return render_template('forgot_password.html')

@app.route('/inventory')
@require_login
def view_inventory():
    products = load_inventory()
    return render_template('inventory.html', products=products)

@app.route('/transactions')
@require_login
def view_transactions():
    log_rows = []
    if os.path.exists(TRANSACTION_FILE):
        with open(TRANSACTION_FILE, "r", encoding="utf-8") as file:
            reader = csv.reader(file)
            next(reader, None)  # Skip header
            log_rows = list(reader)
    return render_template('transactions.html', log_rows=log_rows)

def load_inventory():
    inventory = {}
    if os.path.exists(INVENTORY_FILE):
        with open(INVENTORY_FILE, "r", newline='') as file:
            reader = csv.DictReader(file)
            for row in reader:
                inventory[row['Product ID']] = row
    return inventory

def save_inventory(products):
    fieldnames = ['Product ID', 'Product Name', 'Category', 'Supplier', 'Country of Origin',
                  'Quantity', 'Import Price', 'Export Price', 'Import Date', 'Export Date', 'Status']
    with open(INVENTORY_FILE, "w", newline='') as file:
        writer = csv.DictWriter(file, fieldnames=fieldnames)
        writer.writeheader()
        for product in products.values():
            writer.writerow(product)

def log_transaction(action, product_id, quantity, price=None):
    file_exists = os.path.isfile(TRANSACTION_FILE)

    with open(TRANSACTION_FILE, "a", newline="", encoding="utf-8") as file:
        writer = csv.writer(file)

        # If file is empty, write header first
        if not file_exists or os.stat(TRANSACTION_FILE).st_size == 0:
            writer.writerow(['Action', 'Product ID', 'Quantity', 'Date/Time', 'Price'])

        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        writer.writerow([action, product_id, quantity, timestamp, f"₹{price}" if price else "-"])

def generate_next_product_id(products):
    if not products:
        return "1"
    
    # Extract numeric part of IDs and find the max
    numeric_ids = [int(pid[1:]) for pid in products if pid.startswith("P") and pid[1:].isdigit()]
    next_id_num = max(numeric_ids) + 1 if numeric_ids else 1
    return f"P{next_id_num:03d}"


if __name__ == '__main__':
    app.run(debug=True)