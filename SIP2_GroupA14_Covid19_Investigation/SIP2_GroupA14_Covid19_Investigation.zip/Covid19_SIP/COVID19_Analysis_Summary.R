# Load required libraries
library(readxl)
library(htmltools)

# Set working directory to your data folder (update this!)
setwd("D:/r programming/CSV_usage/Working_directory_UT4/sip")

# Load data
data <- read_excel("COVID19_Analysis_SIP.xlsx")

# Convert columns to numeric (replace spaces / dots if needed)
data$Confirmed <- as.numeric(data$Confirmed)
data$Deaths <- as.numeric(data$Deaths)
data$`Daily.Tests` <- as.numeric(data$`Daily.Tests`)
data$first.dose <- as.numeric(data$first.dose)
data$`Hospital.Bed.Occupancy(%)` <- as.numeric(data$`Hospital.Bed.Occupancy(%)`)
data$`Average.Recovery.Time(Days)` <- as.numeric(data$`Average.Recovery.Time(Days)`)
data$`Quarantine.Compliance(%)` <- as.numeric(data$`Quarantine.Compliance(%)`)
data$`Vaccination.Center.Count` <- as.numeric(data$`Vaccination.Center.Count`)

# Create output folder if not exists and set working directory there
if (!dir.exists("output")) dir.create("output")
setwd("output")

# Define HTML template with sidebar and styling
create_page <- function(title, content) {
  save_html(
    tags$html(
      tags$head(
        tags$style(HTML("
          body {
            font-family: Arial, sans-serif;
            margin: 0; padding: 0;
            display: flex;
            background: #f0f3f7;
          }
          .sidebar {
            width: 280px;
            background-color: #2c3e50;
            color: white;
            height: 100vh;
            position: fixed;
            overflow-y: auto;
            padding: 20px 15px;
          }
          .sidebar h2, .sidebar h3 {
            color: #ecf0f1;
            margin-top: 0;
          }
          .sidebar a {
            color: #bdc3c7;
            text-decoration: none;
            display: block;
            margin: 8px 0;
            font-size: 15px;
            padding-left: 5px;
            border-left: 3px solid transparent;
            transition: all 0.3s ease;
          }
          .sidebar a:hover {
            color: white;
            border-left: 3px solid #1abc9c;
            background-color: #34495e;
          }
          .content {
            margin-left: 280px;
            padding: 30px;
            width: calc(100% - 280px);
            overflow-x: auto;
          }
          h1.section-title {
            color: #34495e;
            margin-bottom: 20px;
          }
          table {
            border-collapse: collapse;
            width: 100%;
            background: white;
          }
          table, th, td {
            border: 1px solid #ddd;
            padding: 8px;
          }
          th {
            background-color: #1abc9c;
            color: white;
            text-align: left;
          }
          tr:nth-child(even){background-color: #f2f2f2;}
          img {
            max-width: 100%;
            height: auto;
            border: 1px solid #ddd;
            box-shadow: 2px 2px 6px rgba(0,0,0,0.1);
          }
          p {
            font-size: 16px;
            color: #333;
          }
        "))
      ),
      tags$body(
        tags$div(class = "sidebar",
                 tags$h2("COVID Dashboard"),
                 tags$p("Select a category:"),
                 tags$a(href = "dashboard_home.html", "🏠 Home"),
                 tags$h3("Graphs"),
                 tags$a(href = "graph1_confirmed_cases.html", "Total Confirmed Cases"),
                 tags$a(href = "graph2_first_dose.html", "First Dose Lollipop"),
                 tags$a(href = "graph3_age_bracket.html", "Age Bracket Histogram"),
                 tags$a(href = "graph4_daily_tests.html", "Daily Tests"),
                 tags$a(href = "graph5_bed_occupancy.html", "Bed Occupancy by Gender"),
                 tags$a(href = "graph6_top5_deaths.html", "Top 5 Deaths Pie Chart"),
                 tags$h3("HTML Queries"),
                 tags$a(href = "query1_top5_confirmed.html", "Top 5 Confirmed"),
                 tags$a(href = "query2_recovery_gender.html", "Recovery by Gender"),
                 tags$a(href = "query3_high_quarantine.html", "High Quarantine"),
                 tags$a(href = "query4_vaccination_summary.html", "Vaccination Summary")
        ),
        tags$div(class = "content",
                 tags$h1(class = "section-title", title),
                 content
        )
      )
    ),
    paste0(gsub(" ", "_", tolower(title)), ".html")
  )
}

# -------------------- Generate Graphs --------------------

# Graph 1: Confirmed Cases Barplot
confirmed_sum <- aggregate(data$Confirmed, by = list(State = data$State), FUN = sum, na.rm = TRUE)
confirmed_sum <- confirmed_sum[order(-confirmed_sum$x), ]

png("bar_confirmed.png", width = 1000, height = 600)
barplot(
  height = confirmed_sum$x,
  names.arg = confirmed_sum$State,
  las = 2,
  col = "steelblue",
  main = "Total Confirmed Cases by State",
  ylab = "Confirmed Cases",
  cex.names = 0.8
)
dev.off()
create_page("Graph 1: Confirmed Cases", tags$img(src = "bar_confirmed.png", alt = "Confirmed Cases"))

# Graph 2: First Dose Lollipop Chart
top10_dose <- data[order(-data$first.dose), ][1:10, ]

png("lollipop_first_dose.png", width=800, height=600)
plot(
  x = top10_dose$first.dose,
  y = seq_along(top10_dose$first.dose),
  xlim = c(0, max(top10_dose$first.dose) * 1.2),
  yaxt = "n",
  xlab = "Dose Count",
  ylab = "",
  main = "Top 10 States - First Dose (Lollipop Chart)",
  pch = 19,
  col = "darkgreen"
)
axis(2, at = seq_along(top10_dose$State), labels = top10_dose$State, las = 1)
segments(x0 = 0, y0 = seq_along(top10_dose$first.dose), x1 = top10_dose$first.dose, y1 = seq_along(top10_dose$first.dose), col = "lightgreen", lwd = 2)
dev.off()
create_page("Graph 2: First Dose", tags$img(src = "lollipop_first_dose.png", alt = "First Dose Lollipop Chart"))

# Graph 3: Age Bracket Histogram
age_counts <- table(data$Age.Bracket)
png("hist_age_bracket.png", width=800, height=600)
barplot(age_counts, main = "Age Bracket Distribution", col = "orange", xlab = "Age Bracket", ylab = "Frequency", las = 2, cex.names = 0.8)
dev.off()
create_page("Graph 3: Age Bracket", tags$img(src = "hist_age_bracket.png", alt = "Age Bracket Histogram"))

# Graph 4: Daily Tests Line Plot
png("line_daily_tests.png", width=800, height=600)
plot(seq_len(nrow(data)), data$`Daily.Tests`, type = "o", xaxt = "n", col = "blue", main = "Daily Tests by State", xlab = "State Index", ylab = "Daily Tests")
axis(1, at = seq_len(nrow(data)), labels = data$State, las = 2, cex.axis=0.7)
dev.off()
create_page("Graph 4: Daily Tests", tags$img(src = "line_daily_tests.png", alt = "Daily Tests"))

# Graph 5: Hospital Bed Occupancy by Gender (Grouped Barplot)
male_occ <- ifelse(data$Gender == "Male", data$`Hospital.Bed.Occupancy(%)`, 0)
female_occ <- ifelse(data$Gender == "Female", data$`Hospital.Bed.Occupancy(%)`, 0)

png("bed_occupancy_gender.png", width=900, height=600)
barplot(
  rbind(male_occ, female_occ),
  beside = TRUE,
  names.arg = data$State,
  las = 2,
  col = c("blue", "pink"),
  legend.text = c("Male", "Female"),
  main = "Hospital Bed Occupancy by Gender"
)
dev.off()
create_page("Graph 5: Bed Occupancy", tags$img(src = "bed_occupancy_gender.png", alt = "Bed Occupancy by Gender"))

# Graph 6: Top 5 Deaths Pie Chart
sorted_data <- data[order(-data$Deaths), ]
top5_data <- head(sorted_data, 5)
png("pie_top5_deaths.png", width=700, height=600)
pie(top5_data$Deaths, labels = top5_data$State, col = rainbow(5), main = "Top 5 States by Deaths")
dev.off()
create_page("Graph 6: Deaths Pie Chart", tags$img(src = "pie_top5_deaths.png", alt = "Top 5 Deaths Pie Chart"))

# -------------------- Generate HTML Queries --------------------

# Query 1: Top 5 Confirmed
top5 <- data[order(-data$Confirmed), ][1:5, c("State", "Confirmed")]
top5_rows <- apply(top5, 1, function(row) paste0("<tr><td>", row["State"], "</td><td>", row["Confirmed"], "</td></tr>"))
top5_table <- paste0("<table><thead><tr><th>State</th><th>Confirmed</th></tr></thead><tbody>", paste(top5_rows, collapse=""), "</tbody></table>")
create_page("Query 1: Top 5 Confirmed", HTML(top5_table))

# Query 2: Average Recovery by Gender
male_avg <- mean(data$`Average.Recovery.Time(Days)`[data$Gender == "Male"], na.rm = TRUE)
female_avg <- mean(data$`Average.Recovery.Time(Days)`[data$Gender == "Female"], na.rm = TRUE)
create_page("Query 2: Recovery by Gender", tags$div(
  tags$p(paste("Male Average Recovery Time (Days):", round(male_avg, 2))),
  tags$p(paste("Female Average Recovery Time (Days):", round(female_avg, 2)))
))

# Query 3: High Quarantine Compliance (>80%)
high_q <- data[data$`Quarantine.Compliance(%)` > 80, c("State", "Quarantine.Compliance(%)")]
high_q_rows <- apply(high_q, 1, function(row) paste0("<tr><td>", row[1], "</td><td>", row[2], "</td></tr>"))
high_q_table <- paste0("<table><thead><tr><th>State</th><th>Quarantine Compliance (%)</th></tr></thead><tbody>", paste(high_q_rows, collapse=""), "</tbody></table>")
create_page("Query 3: High Quarantine", HTML(high_q_table))

# Query 4: Vaccination Center Summary
vcc <- data$`Vaccination.Center.Count`
create_page("Query 4: Vaccination Summary", tags$div(
  tags$p(paste("Max Vaccination Centers:", max(vcc, na.rm = TRUE))),
  tags$p(paste("Min Vaccination Centers:", min(vcc, na.rm = TRUE))),
  tags$p(paste("Mean Vaccination Centers:", round(mean(vcc, na.rm = TRUE), 2)))
))

# -------------------- Dashboard Home --------------------
create_page("Dashboard Home", tags$p("Welcome to the COVID Dashboard. Use the menu on the left to view graphs and HTML queries."))

